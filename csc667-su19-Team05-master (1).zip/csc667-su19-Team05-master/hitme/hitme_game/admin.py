"""hitme_game - admin """

from django.contrib import admin
from .models import GameSession

# Register your models here.

admin.site.register(GameSession)