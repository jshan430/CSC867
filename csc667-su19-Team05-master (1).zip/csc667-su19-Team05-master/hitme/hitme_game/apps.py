"""Hitme - apps"""

from django.apps import AppConfig

class HitmeGameConfig(AppConfig):
    name = 'hitme_game'
